
(function(){

	var gui = require('nw.gui'),
		win = gui.Window.get(),
		macMT = require('./node_modules/mac_mt.node');

	var createEvent = function(name, touch) {
		var evt = new CustomEvent(name, { bubbles: true, cancelable: true } );
		evt.changedTouches = [touch];
		document.dispatchEvent(evt);
	}

	var fings = {};

	var isMoving = function(id, x, y){
		var dx = x - fings[id].x;
		var dy = y - fings[id].y;
		var dist = dx*dx + dy*dy;
		return dist > 0.00001;
	}

	macMT.listener.on = function(fingers){
		var nFingers = fingers.length;
		var newFings = {};
		
		for(var i=0; i<nFingers; i++){

			var f = {};
			f.identifier = fingers[i].id;
			f.pageX = window.innerWidth * fingers[i].x;
			f.pageY = window.innerHeight * fingers[i].y;
			//f.target = document.elementFromPoint(f.pageX, f.pageY);

			if(fings[f.identifier]){
				createEvent('touchmove', f);					

			}
			else{
				createEvent('touchstart', f);	
			}
			
			newFings[f.identifier] = f;
			delete fings[f.identifier];
		}

		for(f in fings){
			createEvent('touchend', fings[f]);		
		}

		fings = newFings;
	}

	win.on('close', function(){
		macMT.end();
		this.close(true);	
	});

	onload = function() {
		gui.Window.get().show();
	}

	macMT.begin();

})();
